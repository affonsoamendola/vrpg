using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Object : MonoBehaviour
{
    public string pre_name;
    public string item_name;

    [TextArea]
    public string description;

    public bool hovered = false;
}
