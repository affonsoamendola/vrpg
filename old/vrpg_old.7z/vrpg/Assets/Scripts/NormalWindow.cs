using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NormalWindow : MonoBehaviour
{
    public string pre_title = "";
    public string title = "Unknown";

    [TextArea]
    public string content = "";

    public Text pre_title_object;
    public Text title_object;
    public Text content_object;

    // Update is called once per frame
    void Update()
    {
        pre_title_object.text = pre_title;
        title_object.text = title;
        content_object.text = content;
    }
}
