using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PlayerMode
{
    PLAYER,
    MASTER
};

public class Player : MonoBehaviour
{
    public PlayerMode current_mode = PlayerMode.PLAYER;

    public GameObject player_canvas;
    public GameObject master_canvas;

    void Start()
    {
        player_canvas = GameObject.FindGameObjectsWithTag("PlayerCanvas")[0];
        master_canvas = GameObject.FindGameObjectsWithTag("MasterCanvas")[0];
    }

    void Update()
    {
        switch(current_mode)
        {
            case PlayerMode.PLAYER:
                if(!player_canvas.activeSelf) player_canvas.SetActive(true);
                if( master_canvas.activeSelf) master_canvas.SetActive(false);
                break;

            case PlayerMode.MASTER:
                if(!master_canvas.activeSelf) master_canvas.SetActive(true);
                if( player_canvas.activeSelf) player_canvas.SetActive(false);
                break;
        }
    }

    void MakePlayer()
    {
        current_mode = PlayerMode.PLAYER;
    }

    void MakeMaster()
    {
        current_mode = PlayerMode.MASTER;
    }
}
