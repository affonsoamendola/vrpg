using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Camera))]
public class ObjectRaycaster : MonoBehaviour
{
    bool disabled = false;

    public Object hit_object = null;

    public Camera cam;

    void Start()
    {
        cam = gameObject.GetComponent<Camera>();
    }

    // Update is called once per frame
    void Update()
    {
        if(hit_object != null && hit_object.hovered) 
            hit_object.hovered = false;

        if(!disabled)
        {   
            RaycastHit hit;
            Ray ray = cam.ScreenPointToRay(Input.mousePosition);

            if(Physics.Raycast(ray, out hit, 100))
            {        
                if( hit_object != hit.transform.gameObject)
                {
                    if(hit.transform.gameObject.GetComponent<Object>() != null)
                    {
                        hit_object = hit.transform.gameObject.GetComponent<Object>();

                        if(hit_object != null && !hit_object.hovered) 
                            hit_object.hovered = true;
                    }    
                }
            }
        }
    }
}
